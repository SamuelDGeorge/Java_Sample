package grail.draw.interfaces;

public interface Point extends Locator {

}
