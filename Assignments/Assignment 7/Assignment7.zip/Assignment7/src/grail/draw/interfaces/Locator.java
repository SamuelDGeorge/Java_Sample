package grail.draw.interfaces;
import util.annotations.Tags;

@Tags({"Locatable"})
public interface Locator {
	public int getX();
	public void setX(int newX);
	public int getY();
	public void setY(int newY);
}
