package grail.draw.objects;

import grail.draw.interfaces.Locator;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.Tags;

@PropertyNames({"X", "Y"})
@EditablePropertyNames({"X", "Y"})
@Tags({"Locatable"})
public class BasicLocator implements Locator{
	protected int x,y;
	
	public BasicLocator() {
		this.x = 0;
		this.y = 0;
	}
	
	public BasicLocator(int x, int y) {
		this.x = x;
		this.y = y;
	}

	
	public int getX() {
		return this.x;
	}

	
	public void setX(int newX) {
		this.x = newX;
		
	}

	
	public int getY() {
		return y;
	}

	
	public void setY(int newY) {
		this.y = newY;
		
	}
	

	
	

}
