package grail.draw.objects;

import grail.draw.interfaces.MutableShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;

@PropertyNames({"X", "Y", "Height", "Width"})
@EditablePropertyNames({"X", "Y", "Height", "Width"})
public class BasicMutableShape extends BasicShape implements MutableShape {

	public BasicMutableShape() {
		super();
	}
	
	public BasicMutableShape(int x, int y) {
		super(x,y);
	}

	
	public void setHeight(int newHeight) {
		this.height = newHeight;
		
	}

	
	public void setWidth(int newWidth) {
		this.width = newWidth;
		
	}

}
