package grail.draw.objects;

import java.awt.Color;

import grail.draw.interfaces.StringShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.STRING_PATTERN)
@PropertyNames({"X", "Y", "Text", "TextColor", "String"})
@EditablePropertyNames({"X", "Y", "Text", "TextColor", "String"})
public class BasicStringShape extends BasicLocator implements StringShape{
	String text;
	String string;
	private Color textColor;
	
	public BasicStringShape() {
		this("Default",0,0);
		
	}
	
	public BasicStringShape(String text) {
		this(text,0,0);
	}
	
	public BasicStringShape(String text, int xPos, int yPos) {
		super();
		this.x = xPos;
		this.y = yPos;
		this.text = text;
		this.string = text;
		this.textColor = Color.black;
	}

	@Override
	public String getText() {
		return text;
	}

	@Override
	public void setText(String text) {
		this.text = text;
		this.string = text;
	}
	
	public String getString() {
		return this.string;
	}
	
	public void setString(String text) {
		this.string = text;
		this.text = text;
	}

	@Override
	public Color getTextColor() {
		return this.textColor;
	}

	@Override
	public void setTextColor(Color newColor) {
		this.textColor = newColor;
		
	}


}
