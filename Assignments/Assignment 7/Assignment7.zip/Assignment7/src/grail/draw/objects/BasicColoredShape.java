package grail.draw.objects;

import java.awt.Color;

import grail.draw.interfaces.ColoredShape;


public class BasicColoredShape extends BasicShape implements ColoredShape{
	protected Color color;
	
	public BasicColoredShape() {
		super();
		this.color = Color.BLACK;
	}

	
	public Color getColor() {
		return this.color;
	}

	
	public void setColor(Color newColor) {
		this.color = newColor;
		
	}

}
