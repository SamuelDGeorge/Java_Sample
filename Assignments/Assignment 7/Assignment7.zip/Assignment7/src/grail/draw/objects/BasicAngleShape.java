package grail.draw.objects;

import java.awt.Color;

import grail.draw.interfaces.AngleShape;
import grail.draw.interfaces.RotatingShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Angle"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"X", "Y", "Height", "Width", "Radius", "Angle", "LeftLine", "RightLine" , "Color"})
@EditablePropertyNames({"X", "Y", "Height", "Width", "Radius", "Angle", "Color"})
public class BasicAngleShape implements AngleShape {
	private RotatingShape leftLine, rightLine;
	private int xPos, yPos, height, width;
	private double radius, angle;
	private Color color;
	
	public BasicAngleShape() {
		this(0,0);
	}
	
	public BasicAngleShape(int initialX, int initialY) {
		final double startingRadius = 50;
		final double leftStartingAngle = Math.PI;
		final double rightStartingAngle = 0;
		final int startingHeightAndWidth = 50;
		
		xPos = initialX;
		yPos = initialY;
		height = startingHeightAndWidth;
		width = startingHeightAndWidth;
		leftLine = new LineRotatingShape(xPos, yPos, startingRadius, leftStartingAngle);
		rightLine = new LineRotatingShape(xPos, yPos, startingRadius, rightStartingAngle);
		setRadius(startingRadius);
		setAngle(rightStartingAngle);
		setColor(Color.BLACK);
	}

	
	public int getX() {
		return xPos;
	}

	
	public void setX(int x) {
		this.xPos = x;
		leftLine.setX(this.xPos);
		rightLine.setX(this.xPos);
	}

	
	public int getY() {
		return yPos;
	}

	
	public void setY(int y) {
		this.yPos = y;
		leftLine.setY(this.yPos);
		rightLine.setY(this.yPos);

	}

	
	public int getHeight() {
		return height;
	}

	
	public int getWidth() {
		return width;
	}

	
	public RotatingShape getLeftLine() {
		return leftLine;
	}

	
	public RotatingShape getRightLine() {
		return rightLine;
	}

	
	@Tags({"move"})
	public void move(int x, int y) {
		xPos = xPos + x;
		yPos = yPos + y;
		this.leftLine.setX(xPos);
		this.leftLine.setY(yPos);
		this.rightLine.setX(xPos);
		this.rightLine.setY(yPos);

	}
	
	public void setRadius(double radius) {
		this.radius = radius;
		leftLine.setRadius(radius);
		rightLine.setRadius(radius);
	}
	
	public void setAngle(double angle) {
		this.angle = angle;
		double halfAngle = angle/2;
		leftLine.setAngle(halfAngle + Math.PI);
		rightLine.setAngle(-halfAngle);
	}
	
	public void rotate(int units) {
		int unitToMoveRight = -units;
		int unitsToMoveLeft = units;
		rightLine.rotate(unitToMoveRight);
		leftLine.rotate(unitsToMoveLeft);
	}

	
	public void setHeight(int height) {
		this.height = height;
		int halfWidth = this.width/2;
		double radius = (double) Math.sqrt((halfWidth * halfWidth) + (height * height));
		this.leftLine.setRadius(radius);
		this.rightLine.setRadius(radius);
		double angle = (double) Math.sinh(height/radius);
		this.rightLine.setAngle(-angle);
		this.leftLine.setAngle(Math.PI + angle);
		
	}

	
	public void setWidth(int width) {
		this.width = width;
		int halfWidth = this.width/2;
		double radius = (double) Math.sqrt((halfWidth * halfWidth) + (height * height));
		this.leftLine.setRadius(radius);
		this.rightLine.setRadius(radius);
		double angle = (double) Math.sinh(height/radius);
		this.rightLine.setAngle(-angle);
		this.leftLine.setAngle(Math.PI + angle);
		
	}

	
	public double getRadius() {
		return radius;
	}

	
	public double getAngle() {
		return angle;
	}

	
	public Color getColor() {
		return color;
	}

	
	public void setColor(Color newColor) {
		this.color = newColor;
		this.leftLine.setColor(newColor);
		this.rightLine.setColor(newColor);
		
		
	}

	
	public void scale(double scaleFactor) {
		this.rightLine.setRadius(this.rightLine.getRadius() * scaleFactor);
		this.leftLine.setRadius(this.leftLine.getRadius() * scaleFactor);
		
	}

}
