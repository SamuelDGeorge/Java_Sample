package grail.draw.objects;

import grail.draw.interfaces.RotatingShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"RotatingLine"})
@StructurePattern(StructurePatternNames.LINE_PATTERN)
@PropertyNames({"X", "Y", "Height", "Width", "Radius" ,"Color"})
@EditablePropertyNames({"X", "Y","Angle", "Radius","Color"})
public class LineRotatingShape extends BasicColoredShape implements RotatingShape{
	private double radius, angle;

	public LineRotatingShape() {
	this(0,0,0,0);
	}
	
	public LineRotatingShape(int x, int y, double radius, double angle) {
		super();
		this.x = x;
		this.y = y;
		setRadius(radius);
		setAngle(angle);
	}


	
	public void setRadius(double val) {
		this.radius = val;
		double tempHeight =  this.radius * Math.sin(this.angle);
		this.height = (int) tempHeight;
		double tempWidth = this.radius * Math.cos(this.angle);
		this.width = (int) tempWidth;
		
	}

	
	public void setAngle(double val) {
		this.angle = val;
		double tempHeight =  this.radius * Math.sin(this.angle);
		this.height = (int) tempHeight;
		double tempWidth = this.radius * Math.cos(this.angle);
		this.width = (int) tempWidth;
		
	}

	@Tags({"rotate"})
	public void rotate(int units) {
		final double secondsInAMinute = 60;
		final double fullRotation = Math.PI * 2;
		final double clockUnit = fullRotation/secondsInAMinute;
		double distanceToRotate = units * clockUnit;
		double angleToSet = this.angle + distanceToRotate;
		setAngle(angleToSet);
	}

	
	public double getRadius() {
		return this.radius;
	}

}
