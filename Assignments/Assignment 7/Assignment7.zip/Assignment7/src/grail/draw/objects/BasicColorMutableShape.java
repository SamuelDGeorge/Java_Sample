package grail.draw.objects;

import java.awt.Color;

import grail.draw.interfaces.ColorMutableShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;

@PropertyNames({"X", "Y", "Height", "Width", "Color"})
@EditablePropertyNames({"X", "Y", "Height", "Width", "Color"})
public class BasicColorMutableShape extends BasicMutableShape implements ColorMutableShape{
	protected Color color;
	
	public BasicColorMutableShape() {
		super();
		this.color = Color.BLACK;
	}

	
	public void setColor(Color newColor) {
		this.color = newColor;
		
	}

	
	public Color getColor() {
		return color;
	}

}
