package grail.commander;

public interface CommandInterpreter {
	public String getCommand();
	public void setCommand(String commandLine);
	public String getErrors();
}
