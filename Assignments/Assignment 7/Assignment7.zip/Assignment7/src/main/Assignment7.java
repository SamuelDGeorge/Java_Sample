package main;

import java.awt.Color;

import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import grail.avatar.Avatar;
import grail.avatar.BasicAvatar;
import grail.commander.BasicCommandInterpreter;
import grail.commander.CommandInterpreter;
import grail.helpers.BasicTable;
import grail.helpers.ScannerBean;
import grail.helpers.Table;
import grail.interfaces.ArrayStore;
import grail.scene.BasicBridgeScene;
import grail.scene.BridgeScene;
import util.misc.ThreadSupport;

public class Assignment7 {
	
	public static void main(String[] args) {
        demonstrateTable();
		demonstrateBridgeSceneWithCommands();
	}
	
	private static void demonstrateTable() {
		System.out.println("Demoing Table!");
		Table testTable = new BasicTable();
		
		final String firstObject = "firstObject";
		final String stringObject = "StringObject";
		final String Integer = "Integer";
		final String nullObject = "Null";
		
		//first we add elements to a table
		testTable.put(firstObject, new Object());
		testTable.put(stringObject, "String");
		testTable.put(Integer, 0);
		
		//these two won't be added
		testTable.put(null, new Object());
		testTable.put(nullObject, null);
		
		//we will get them and print them back
		System.out.println("Get these:");
		System.out.println(testTable.get(firstObject));
		System.out.println(testTable.get(stringObject));
		System.out.println(testTable.get(Integer));
		
		System.out.println("These will not be found:");
		//"Null" was not added so this will give you null
		System.out.println(testTable.get(nullObject));
		//getting something with a missing key will give you null as well
		System.out.println(testTable.get("KeyNotFound"));
		
		//show all the elements that were added
		System.out.println("Full List:");
		testTable.print();
		
		
	}
	
	private static void demonstrateBridgeSceneWithCommands() {
		final int reasonableWaitTime = 2000;
		
		//build the objects
		Avatar arthur = new BasicAvatar("arthur.jpg");
		arthur.setBodyColor(Color.YELLOW);
		arthur.setTextColor(Color.YELLOW);
		
		Avatar lancelot = new BasicAvatar("lancelot.jpg");
		lancelot.setBodyColor(Color.RED);
		lancelot.setTextColor(Color.RED);
		
		Avatar robin =  new BasicAvatar("robin.jpg");
		robin.setBodyColor(Color.CYAN);
		robin.setTextColor(Color.CYAN);
		
		Avatar galahad = new BasicAvatar("galahad.jpg");
		galahad.setBodyColor(Color.PINK);
		galahad.setTextColor(Color.PINK);
		
		Avatar guard = new BasicAvatar("guard.jpg");
		guard.setBodyColor(Color.DARK_GRAY);
		guard.setTextColor(Color.DARK_GRAY);

		//initialize the scene
		final int editorWidth = 1600;
		final int editorHeight = 1000;
		BridgeScene scene = new BasicBridgeScene(arthur, lancelot, robin, galahad, guard);
		OEFrame editor = ObjectEditor.edit(scene);
		editor.hideMainPanel();
		editor.setSize(editorWidth,editorHeight);
		ArrayStore scanner = new ScannerBean();
		OEFrame editorTwo = ObjectEditor.edit(scanner);
		CommandInterpreter command = new BasicCommandInterpreter(scene, scanner);
		OEFrame editorThree = ObjectEditor.edit(command);

		
		//implement the approach method
		galahad.setText("I am going to approach!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.approach(galahad);
		galahad.setText("I am Here!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//implement the say command one
		command.setCommand("say \"Hello There my good Knight!\"");
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//implement a knight response
		command.setCommand("you can put any noncommand words before and it finds the command say \"Hello Guard!!\" after is also ignored");
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//implement the move command
		command.setCommand("Now I am going to move Lancelot 50 100");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//implement the move command with one plus/minus
		command.setCommand("Now I am going to move Robin 70 - 100");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//implement the move command with one plus/minus
		command.setCommand("Now I am going to move Robin - 70 100");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//implement the move command with both
		command.setCommand("Now I am going to move Robin + 70 - 100");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//error given if their is no command in the string
		command.setCommand("Nothing was found");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//deals with wrong implementation as well. 
		command.setCommand("Or errors are show if implementation is bad move NonExistantKnight 40 30");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//deals with wrong implementation as well. 
		command.setCommand("Or move Arthur notaDistance notADistance");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//deals with wrong implementation as well. 
		command.setCommand("Or say missingQuotesOnThisOne");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//deals with commands that are commands, but have not been implemented yet. 
		command.setCommand("approach Arthur");
		System.out.println(command.getErrors());
		editor.refresh();
		editorTwo.refresh();
		editorThree.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
	}
	

	
	
}
