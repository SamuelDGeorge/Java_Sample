package main;

import java.awt.Color;

import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import grail.avatar.Avatar;
import grail.avatar.BasicAvatar;
import grail.helpers.ScannerBean;
import grail.interfaces.ArrayStore;
import grail.scene.BasicBridgeScene;
import grail.scene.BridgeScene;
import util.misc.ThreadSupport;

public class Assignment6 {
	
	public static void main(String[] args) {
        demonstrateBridgeScene();
        demonstrateScannerBean();
	}
	
	private static void demonstrateBridgeScene() {
		final int reasonableWaitTime = 2000;
		
		//build the objects
		Avatar arthur = new BasicAvatar("arthur.jpg");
		arthur.setBodyColor(Color.YELLOW);
		arthur.setTextColor(Color.YELLOW);
		
		Avatar lancelot = new BasicAvatar("lancelot.jpg");
		lancelot.setBodyColor(Color.RED);
		lancelot.setTextColor(Color.RED);
		
		Avatar robin =  new BasicAvatar("robin.jpg");
		robin.setBodyColor(Color.CYAN);
		robin.setTextColor(Color.CYAN);
		
		Avatar galahad = new BasicAvatar("galahad.jpg");
		galahad.setBodyColor(Color.PINK);
		galahad.setTextColor(Color.PINK);
		
		Avatar guard = new BasicAvatar("guard.jpg");
		guard.setBodyColor(Color.DARK_GRAY);
		guard.setTextColor(Color.DARK_GRAY);

		//initialize the scene
		final int editorWidth = 1600;
		final int editorHeight = 1000;
		BridgeScene scene = new BasicBridgeScene(arthur, lancelot, robin, galahad, guard);
		OEFrame editor = ObjectEditor.edit(scene);
		editor.setSize(editorWidth,editorHeight);
		
		//implement the approach method
		galahad.setText("I am going to approach!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.approach(galahad);
		galahad.setText("I am Here!");
		editor.refresh();
		
		//show that it works only when un-occupied
		arthur.setText("I want to Approach!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.approach(arthur);
		arthur.setText("But I can't!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//demonstrate say Method with pass
		scene.sayScene("I will now Say");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("I will question");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("What do you Need?");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Can I Cross?");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Yes you may Cross!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Yay! Here I go");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.knightPassed();
		scene.marchAvatar(editor);
		galahad.setText("I'm Across! Lancelot?");
		lancelot.setText("My Turn");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//demonstrate say method with knight fail
		scene.approach(lancelot);
		scene.sayScene("Hello Lancelot");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Hello Guard");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("What do you want?");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("May I cross?");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("No!!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Ahhhhh");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.avatarFailed();
		scene.fallAvatar(editor);
		arthur.setText("Finally! My Turn.");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		
		//demonstrate say method with guard fail
		scene.approach(arthur);
		scene.sayScene("Hello Arthur!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Time for you to Pay!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("What?");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("To the Gorge!!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.sayScene("Noooooooo!");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.avatarFailed();
		scene.fallAvatar(editor);
		
		//Arthur can also walk across
		arthur.setText("Now I can join Galahad");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime);
		scene.knightPassed();
		scene.marchAvatar(editor);
		
		//ending...
		final int distanceToScroll = 100;
		robin.setText("Where did everybody go? , anddd Scroll.");
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime * 2);
		scene.scroll(distanceToScroll, distanceToScroll);
		editor.refresh();
		ThreadSupport.sleep(reasonableWaitTime + reasonableWaitTime + reasonableWaitTime);
		
	}
	
	
	private static void demonstrateScannerBean() {
		final int windowPixelWidth = 750;
		final int windowPixelHeight = 350;
		final int appropriateSleepTime = 4000;
		ArrayStore scannerbean = new ScannerBean();
        OEFrame editor = ObjectEditor.edit(scannerbean);
        scannerbean.setScannedString("\"First try all the non-command cases:\"  0098 WORD  {  }  +  -  err0r");
        editor.select(scannerbean, "Tokens");
        editor.setSize(windowPixelWidth, windowPixelHeight);
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.setScannedString("\"Next we do first set of commands\" call define move proceedall REDO");
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.setScannedString("\"Next we do second set of commands\" Approach REPEAT RotateLeftArm RotateRightArm");
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.setScannedString("\"Next we do final set of commands\" Say SLEep Thread Undo Wait");
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.setScannedString("\"Last we show errors:\" \"MissingEndQuote  m!x   {NOSPACE }NOSPACE   @manySpaces");
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.getTokenList().clear();
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.setScannedString("History Was Cleared");
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);
        scannerbean.setScannedString("More was added");
        editor.refresh();
        ThreadSupport.sleep(appropriateSleepTime);

	}
	
}
