package grail.avatar;

import java.awt.Color;
import grail.draw.interfaces.AngleShape;
import grail.draw.interfaces.ImageShape;
import grail.draw.interfaces.RotatingShape;
import grail.draw.interfaces.StringShape;
import util.annotations.Tags;

@Tags({"Avatar"})
public interface Avatar {
	public void setX(int xPos);
	public int getX();
	public void setY(int yPos);
	public int getY();
	public int getHeight();
	public int getWidth();
	public StringShape getStoredText();
	public void setStoredText(StringShape setVal);
	public ImageShape getHead();
	public AngleShape getArms();
	public AngleShape getLegs();
	public RotatingShape getBody();
	public void move(int x, int y);
	public void scale(double scaleValue);
	public void setText(String text);
	public String getText();
	public void setLocation(int x, int y);
	public void setBodyColor(Color newBodyColor);
	public void setTextColor(Color newTextColor);
	public Color getBodyColor();
	public Color getTextColor();

}
