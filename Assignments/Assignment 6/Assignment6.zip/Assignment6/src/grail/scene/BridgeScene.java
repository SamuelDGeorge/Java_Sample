package grail.scene;

import bus.uigen.OEFrame;
import grail.avatar.Avatar;
import grail.draw.interfaces.BridgeMoat;
import grail.draw.interfaces.Platform;

public interface BridgeScene {
	public Avatar getArthur();
	public Avatar getLancelot();
	public Avatar getRobin();
	public Avatar getGalahad();
	public Avatar getGuard();
	public BridgeMoat getGorge();
	public Platform getKnightArea();
	public Platform getGuardArea();
	public void scroll(int x , int y);
	public boolean getOccupied();
	public void approach(Avatar avatarToApproach);
	public void sayScene(String lineOfDialogue);
	public void knightPassed();
	public void avatarFailed();
	public boolean getKnightTurn();
	public void marchAvatar(OEFrame scene);
	public void fallAvatar(OEFrame scene);
}
