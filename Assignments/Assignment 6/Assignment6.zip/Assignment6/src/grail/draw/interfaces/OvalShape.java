package grail.draw.interfaces;

public interface OvalShape extends ColoredShape{
	public void setHeight(int newVal);
	public void setWidth(int newVal);
	public boolean getFilled();
	public void setFilled(boolean isFilled);
}
