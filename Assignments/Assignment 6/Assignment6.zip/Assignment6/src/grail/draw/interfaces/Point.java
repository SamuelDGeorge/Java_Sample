package grail.draw.interfaces;

public interface Point {
	public int getX();
	public void setX(int newX);
	public int getY();
	public void setY(int newY);
}
