package grail.draw.interfaces;

public interface Shape extends Point{
	public int getHeight();
	public int getWidth();
}
