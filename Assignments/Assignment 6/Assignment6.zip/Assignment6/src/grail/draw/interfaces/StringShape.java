package grail.draw.interfaces;

import java.awt.Color;

public interface StringShape extends Point{

	public String getText();
	public void setText(String text);
	public Color getColor();
	public void setColor(Color newColor);
	public void setString(String text);
	public String getString();
}
