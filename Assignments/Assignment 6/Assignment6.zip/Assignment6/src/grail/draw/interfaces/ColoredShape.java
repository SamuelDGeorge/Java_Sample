package grail.draw.interfaces;

import java.awt.Color;

public interface ColoredShape extends Point{
	public int getHeight();
	public int getWidth();
	public Color getColor();
	public void setColor(Color newColor);
}
