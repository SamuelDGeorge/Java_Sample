package grail.draw.interfaces;

import util.annotations.Tags;

@Tags({"Angle"})
public interface AngleShape extends RotatingShape{
		public void setHeight(int height);
		public void setWidth(int width);
		public RotatingShape getLeftLine();
		public RotatingShape getRightLine();
		public void move(int x, int y);
		public double getRadius();
		public double getAngle();
		public void scale(double scaleFactor);
}
