package grail.draw.objects;

import java.awt.Color;

import grail.draw.interfaces.OvalShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;


@StructurePattern(StructurePatternNames.OVAL_PATTERN)
@PropertyNames({"X", "Y", "Width", "Height", "Color", "Filled"})
@EditablePropertyNames({"X", "Y", "Width", "Height", "Color", "Filled"})
public class BasicOvalShape implements OvalShape {
	private int x,y,height,width;
	private Color color;
	private boolean filled;
	
	public BasicOvalShape() {
		final int defaultValue = 100;
		this.x = defaultValue;
		this.y = defaultValue;
		this.height = defaultValue;
		this.width = defaultValue;
		this.color = Color.BLACK;
		this.filled = true;
	}

	@Override
	public int getX() {
		return x;
	}

	@Override
	public void setX(int x) {
		this.x = x;

	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public void setY(int y) {
		this.y = y;

	}

	@Override
	public int getHeight() {
		return height;
	}

	@Override
	public int getWidth() {
		return width;
	}

	@Override
	public void setHeight(int newVal) {
		this.height = newVal;

	}

	@Override
	public void setWidth(int newVal) {
		this.width = newVal;

	}

	@Override
	public Color getColor() {
		return color;
	}

	@Override
	public void setColor(Color newColor) {
		this.color = newColor;
		
	}

	@Override
	public boolean getFilled() {
		return this.filled;
	}

	@Override
	public void setFilled(boolean isFilled) {
		this.filled = isFilled;
		
	}

}
