package grail.draw.objects;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import grail.draw.interfaces.ImageShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;

@StructurePattern(StructurePatternNames.IMAGE_PATTERN)
@PropertyNames({"Height", "Width", "X", "Y","ImageFileName"})
@EditablePropertyNames({"Height", "Width", "X", "Y", "ImageFileName"})
public class BasicImageShape implements ImageShape {
	private int height, width, xPos, yPos;
	private String imageFileName;
	private Icon image;
	
	public BasicImageShape(String imageFileName) {
		this.imageFileName = imageFileName;
		try {
			image = new ImageIcon(imageFileName);
			this.height = image.getIconHeight();
			this.width = image.getIconWidth();
		} catch (Exception e) {
			System.out.println("The image was not found!!");
		}

	}

	@Override
	public int getHeight() {
		return height;
	}

	@Override
	public void setHeight(int newHeight) {
		this.height = newHeight;
		
	}

	@Override
	public int getWidth() {
		return width;
	}

	@Override
	public void setWidth(int newWidth) {
		this.width = newWidth;
		
	}

	@Override
	public int getX() {
		return xPos;
	}

	@Override
	public void setX(int x) {
		this.xPos = x;
		
	}

	@Override
	public int getY() {
		return yPos;
	}

	@Override
	public void setY(int y) {
		this.yPos = y;
		
	}

	@Override
	public String getImageFileName() {
		return imageFileName;
	}

	@Override
	public void setImageFileName(String newName) {
		this.imageFileName = newName;
		
	}

}
