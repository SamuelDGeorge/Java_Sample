package grail.view;

import java.beans.PropertyChangeListener;

import grail.paint.PaintListener;

public interface PlatformView extends PaintListener, PropertyChangeListener {

}
