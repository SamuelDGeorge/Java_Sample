package grail.animation.two;

import grail.avatar.Avatar;
public interface AnimatorInterface {
	public void walkAvatar(Avatar toAnimate);
	public void clapAvatar(Avatar toAnimate);
}
