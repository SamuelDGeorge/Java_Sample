package grail.runnables;


public class DefaultCommand implements Runnable {

	public void run() {
		//do nothing

	}


}
