package main;

import java.awt.Color;

import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import grail.avatar.Avatar;
import grail.avatar.BasicAvatar;
import grail.scene.BasicBridgeScene;
import grail.scene.BridgeScene;
import grail.view.BasicConsole;
import grail.view.Console;
import util.misc.ThreadSupport;

public class Assignment8 {
	
	public static void main(String[] args) {
		demonstrateBridgeSceneWithCommands();
	}
	
	private static void demonstrateBridgeSceneWithCommands() {
		final int reasonableWaitTime = 3000;
		
		//build the objects
		Avatar arthur = new BasicAvatar("arthur.jpg");
		arthur.setBodyColor(Color.YELLOW);
		arthur.setTextColor(Color.YELLOW);
		
		Avatar lancelot = new BasicAvatar("lancelot.jpg");
		lancelot.setBodyColor(Color.RED);
		lancelot.setTextColor(Color.RED);
		
		Avatar robin =  new BasicAvatar("robin.jpg");
		robin.setBodyColor(Color.CYAN);
		robin.setTextColor(Color.CYAN);
		
		Avatar galahad = new BasicAvatar("galahad.jpg");
		galahad.setBodyColor(Color.PINK);
		galahad.setTextColor(Color.PINK);
		
		Avatar guard = new BasicAvatar("guard.jpg");
		guard.setBodyColor(Color.DARK_GRAY);
		guard.setTextColor(Color.DARK_GRAY);

		//initialize the scene
		final int editorWidth = 1600;
		final int editorHeight = 1000;
		BridgeScene scene = new BasicBridgeScene(arthur, lancelot, robin, galahad, guard);
		Console console = new BasicConsole(scene);
		System.out.println("Displaying changes to scene: " + console.getScene());
		OEFrame editor = ObjectEditor.edit(scene);
		editor.setSize(editorWidth,editorHeight);
		
		
		//demonstrate approach
		galahad.setBasicText("I am going to approach!");
		ThreadSupport.sleep(reasonableWaitTime);
		
		scene.approach(galahad);
		ThreadSupport.sleep(reasonableWaitTime);
		
		//demonstrate moving all body parts a bit.
		final int amountToRotate = 4;
		galahad.setBasicText("Moving all my body parts!");
		galahad.getArms().getLeftLine().rotate(-amountToRotate);
		galahad.getArms().getRightLine().rotate(amountToRotate);
		galahad.getLegs().getLeftLine().rotate(-amountToRotate);
		galahad.getLegs().getRightLine().rotate(amountToRotate);
		
		//demonstrate more talking
		ThreadSupport.sleep(reasonableWaitTime);
		arthur.setBasicText("Good Work Galahad!");
		lancelot.setBasicText("Yeah.. Nice...");
		robin.setBasicText("When is it my turn?");
		guard.setBasicText("You guys are driving me nuts...");
		
		//demonstrate moving
		final int amountToMoveX = 100;
		final int amountToMoveY = 0;
		ThreadSupport.sleep(reasonableWaitTime);
		arthur.setBasicText("Now we move!");
		arthur.move(amountToMoveX, amountToMoveY);
		lancelot.move(amountToMoveX, amountToMoveY);
		robin.move(amountToMoveX, amountToMoveY);
		
	}
	

	
	
}
