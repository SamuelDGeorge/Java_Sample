package grail.draw.interfaces;

public interface Rectangle extends ColorMutableShape{

}
