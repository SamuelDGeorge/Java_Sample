package grail;

import util.annotations.EditablePropertyNames; 
import util.annotations.PropertyNames;
import util.annotations.StructurePattern; 
import util.annotations.StructurePatternNames; 
import util.annotations.Tags;
import grail.interfaces.WordToken;
import grail.interfaces.NumberToken;
import grail.interfaces.StoreToken;
import grail.interfaces.MutableIterator;
import grail.interfaces.StringScan;

@Tags({"ScannerBean"}) 
@StructurePattern(StructurePatternNames.BEAN_PATTERN) 
@PropertyNames({"ScannedString"}) 
@EditablePropertyNames({"ScannedString"})

public class ScannerBean implements StringScan {
	private String scannedString = ""; 
	
	public ScannerBean() {
		//do nothing
	}
	
	public void setScannedString(String input) {
		scannedString = input;
		printObjectTypes(input);
	}
	
	public String getScannedString() {
		return scannedString;
	}
	
	public void printObjectTypes(String input) {
		MutableIterator scan = new QuoteMutableIterator(input);
		while (scan.hasNext()) {
			
			String currentToken = scan.next();
            
            printTokenType(currentToken);
		}
		
	}
	
	private void printTokenType(String token) {
		int currentTokenLength = token.length();
		int index = 0;
			char currentChar = token.charAt(index);
			if ((currentChar == '+') && currentTokenLength == 1) {
				StoreToken output = new PlusStoreToken(token);
				System.out.println(output);
				System.out.println(output.getInput());
				
			} else if (currentChar == '-' && currentTokenLength == 1) {
				StoreToken output = new MinusStoreToken(token);
				System.out.println(output);
				System.out.println(output.getInput());
			} else if (currentChar == '"') {
				if ((token.charAt(currentTokenLength - 1) == '"') && currentTokenLength >1){
					token = processFinalToken(token);
					StoreToken output = new QuotedStoreToken(token);
					System.out.println(output);
					System.out.println(output.getInput());
					
				} else {
					token = removeStartQuote(token);
					StoreToken output = new QuotedStoreToken(token);
					System.out.println(output);
					System.out.println("Error! Missing End Quote, token stored as single word:");
					System.out.println(output.getInput());
					
				}
			} else if (isNumber(token)) {
				NumberToken numClass = new NumberStoreToken(token);
				System.out.println(numClass);
				System.out.println(numClass.getInput());
				System.out.println(numClass.getValue());
				
			} else if (isWord(token)) {
				WordToken wordClass = new WordStoreToken(token);
				System.out.println(wordClass);
				System.out.println(wordClass.getInput());
				System.out.println(wordClass.getValue());
				
			} else if (currentChar == '{' && currentTokenLength == 1) {
				StoreToken output = new StartStoreToken(token);
				System.out.println(output);
				System.out.println(output.getInput());
				
			}else if (currentChar == '}' && currentTokenLength == 1) {
				StoreToken output = new EndStoreToken(token);
				System.out.println(output);
				System.out.println(output.getInput());
				
			}else {
				System.out.println("Error! The following contains illegal character mix and was ignored:");
				System.out.println(token);
				
			}
		
	}
	
	private String removeStartQuote(String token) {
		String returnString = "";
		int index = 0;
		while (index < token.length() - 1) {
			returnString = returnString + token.charAt(index + 1);
			index++;
		}
		
		return returnString;
	} 
	
	private boolean isWord(String token) {
		int index = 0;
		while (index < token.length()) {
			if (!Character.isLetter(token.charAt(index))) {
				return false;
			}
			index++;
		}
		
		return true;
	}
	
	private boolean isNumber(String token){
		int index = 0;
		while (index < token.length()) {
			if (!Character.isDigit(token.charAt(index))) {
				return false;
			}
			index++;
		}
		
		return true;
	}	
	public static boolean isLetter(char inputChar) {
		return ((inputChar >= 'a' && inputChar <= 'z') || (inputChar >= 'A' && inputChar <= 'Z'));
	} 
	
	private boolean checkForStartQuote(String token) {
		if (token.length() > 0 && token.charAt(0) == '"') {
			return true;
		} 
		return false;
		
	}
	
	private boolean checkForEndQuote(String token) {
		if (token.length() > 0  && token.charAt(token.length() - 1) == '"') {
			return true;
		}
		
		return false;
	}
	
	
	private String processFinalToken(String token) {
		String returnString = token;
		
		if (checkForStartQuote(token) && checkForEndQuote(token)) {
			returnString = returnString.substring(1, token.length() - 1);
		}
		
		return returnString;
	}
	
}
