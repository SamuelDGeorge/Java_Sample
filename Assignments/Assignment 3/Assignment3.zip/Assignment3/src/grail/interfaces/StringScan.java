package grail.interfaces;

public interface StringScan {
	public void setScannedString(String scannedString);
	public String getScannedString();
	public void printObjectTypes(String input);
}
