package main;

import java.util.Scanner;

import grail.ScannerBean;
import grail.interfaces.StringScan;

public class Assignment3 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Welcome to String Parser.");
		
		boolean keepRunning = true;
		while (keepRunning) {
			System.out.println("Please give a string of numbers, words, or symbol \"+\", \"-\", \"{\" or \"}\"");
			String inputString = input.nextLine();
			if (checkForPeriod(inputString)) {
				System.out.println("Thank you for using this program!");
				break;
			}
			StringScan processor = new ScannerBean();
			processor.setScannedString(inputString);
			
		}
		input.close();
	}
	
	
	
	private static boolean checkForPeriod(String input) {
			
			if (input.length() > 0 && input.charAt(0) == '.') {
				return true;
			} 
			
			return false;
			
	}

		
	
}
