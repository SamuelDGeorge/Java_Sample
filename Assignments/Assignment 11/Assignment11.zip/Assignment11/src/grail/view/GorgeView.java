package grail.view;

import java.beans.PropertyChangeListener;

import grail.paint.PaintListener;

public interface GorgeView extends PaintListener, PropertyChangeListener {

}
