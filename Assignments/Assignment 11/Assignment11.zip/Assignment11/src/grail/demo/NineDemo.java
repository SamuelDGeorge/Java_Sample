package grail.demo;

public interface NineDemo extends Demo{
 public int getProgress();
}
