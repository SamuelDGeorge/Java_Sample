package grail.interfaces;

public interface StoreToken {
	public void setInput(String storedString);
	public String getInput();
}
