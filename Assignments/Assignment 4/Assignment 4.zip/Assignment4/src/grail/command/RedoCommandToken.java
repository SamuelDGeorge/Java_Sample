package grail.command;
import util.annotations.Tags;

@Tags({"redo"})
public class RedoCommandToken extends CommandStoreToken {

	public RedoCommandToken(String input) {
		super(input);
	}

}
