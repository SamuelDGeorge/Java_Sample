package grail.command;

import util.annotations.Tags;

@Tags({"move"})

public class MoveCommandToken extends CommandStoreToken{

	public MoveCommandToken(String input) {
		super(input);
	}

}
