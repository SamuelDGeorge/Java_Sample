package grail.command;
import util.annotations.Tags;

@Tags({"proceedAll"})
public class ProceedAllCommandToken extends CommandStoreToken {

	public ProceedAllCommandToken(String input) {
		super(input);
	}

}
