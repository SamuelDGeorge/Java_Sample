package grail;

import util.annotations.EditablePropertyNames; 
import util.annotations.PropertyNames;
import util.annotations.StructurePattern; 
import util.annotations.StructurePatternNames; 
import util.annotations.Tags;


@Tags({"ScannerBean"}) 
@StructurePattern(StructurePatternNames.BEAN_PATTERN) 
@PropertyNames({"ScannedString"}) 
@EditablePropertyNames({"ScannedString"})

public class ScannerBean {
	private String scannedString = ""; 
	private int savedPosition = 0;
	
	public ScannerBean() {
		//do nothing
	}
	
	public void setScannedString(String input) {
		scannedString = input;
		printTokenTypes(input);
	}
	
	public String getScannedString() {
		return scannedString;
	}
	
	public void printTokenTypes(String input) {
		Token scan = new Token(input);
		savedPosition = 0;
		while (scan.hasNext()) {
			
			String currentToken = scan.next();
            String finalToken = quoteFinder(scan, currentToken, input);
			String outputString = "";
			
			outputString = tokenTypeIdentifier(finalToken) + ": " + processFinalToken(finalToken) + "\n";
			System.out.println(outputString);
		}
		
	}
	
	public String tokenTypeIdentifier(String token) {
		String returnString = "Default";
		int currentTokenLength = token.length();
		int index = 0;
	
			char currentChar = token.charAt(index);
			if ((currentChar == '+' || currentChar == '-') && currentTokenLength == 1) {
				returnString = "Sign";
				return returnString;
			} else if (currentChar == '"') {
				if ((token.charAt(currentTokenLength - 1) == '"') && currentTokenLength >1){
					returnString = "quoted string";
					return returnString;
				} else {
					returnString = "quoted string E: Missing end quote";
					return returnString;
				}
			} else if (Character.isDigit(currentChar)) {
					returnString = "number";
			} else if (isLetter(currentChar)) {
					returnString = "word";
				
			} else {
				//Does not specify a type. I created a "mixed token" type to deal with symbols
				returnString = "mixed token";
			}
		
		return returnString;
	}
	
	public static boolean isLetter(char inputChar) {
		return ((inputChar >= 'a' && inputChar <= 'z') || (inputChar >= 'A' && inputChar <= 'Z'));
	} 
	
	public boolean checkForStartQuote(String token) {
		if (token.length() > 0 && token.charAt(0) == '"') {
			return true;
		} 
		return false;
		
	}
	
	public boolean checkForEndQuote(String token) {
		if (token.length() > 0  && token.charAt(token.length() - 1) == '"') {
			return true;
		}
		
		return false;
	}
	
	private String quoteFinder(Token scan, String currentToken, String fullString) {
		String finalToken = "";
		
		if (checkForStartQuote(currentToken) && !checkForEndQuote(currentToken) && scan.hasNext()) {
			finalToken = processQuote(scan.getCurrentPosition(), currentToken, fullString); 
			scan.setCurrentPosition(savedPosition);
		} else if (currentToken.charAt(0) == '"' && currentToken.length() == 1) {
			finalToken = processQuote(scan.getCurrentPosition(), currentToken, fullString); 
			scan.setCurrentPosition(savedPosition);
		} else {
			finalToken = currentToken;
		}
		return finalToken;
	}
	
	
	private String processQuote(int startingPosition, String currentToken, String fullString) {
		String returnString = currentToken;
		int index = startingPosition;
		
		while (index < fullString.length()) {
			char currentChar = fullString.charAt(index);
			if (currentChar == '"') {
				returnString = returnString + currentChar;
				index++;
				savedPosition = index;
				break;
			} else {
				returnString = returnString + currentChar;
				index++;
				if (index == fullString.length()) {
					returnString = currentToken;
					savedPosition = startingPosition;
					break;
				}
			}
		}
		
		return returnString;
	}
	
	private String processFinalToken(String token) {
		String returnString = token;
		
		if (checkForStartQuote(token) && checkForEndQuote(token)) {
			returnString = returnString.substring(1, token.length() - 1);
		}
		
		return returnString;
	}
	
	
	
		
	
	
}
