package grail.scanner;

import java.util.Iterator;

public class TokenScanner implements Iterator<String>{

	private String toScan = "";
	private int stringLength = 0;
	private int currentIndexPosition = 0;
	
	public TokenScanner() {
		
	}
	
	public TokenScanner(String input) {
		setInitialConditions(input);
	}
	

	public boolean hasNext() {
		char currentChar = 'a';
		
		//probes for another token. Returns false if it does not find one.
		int currentPosition = currentIndexPosition;
		if ((currentPosition < stringLength)) {
			currentChar = toScan.charAt(currentPosition);
		}	
		while ((currentChar == ' ') && currentIndexPosition < stringLength) {
			currentPosition++;
			if ((currentPosition < stringLength)) {
				currentChar = toScan.charAt(currentPosition);
			} else {
				break;
			}
		}
		
		if (currentPosition < (stringLength)) {
			return true;
		} 
			return false;
		
		
	}


	public String next() {
		String currentReturn = "";
		
		char currentChar = toScan.charAt(currentIndexPosition);
		if (!(currentChar == ' ')){
			while(!(currentChar == ' ') && currentIndexPosition < stringLength) {
				currentReturn = currentReturn + currentChar;
				currentIndexPosition++;
					if (currentIndexPosition < toScan.length()){
					currentChar = toScan.charAt(currentIndexPosition);
					}
			}
		} else {
			clearWhiteSpace();
			if (currentIndexPosition < toScan.length()){
				currentChar = toScan.charAt(currentIndexPosition);
			}
			while(!(currentChar == ' ') && currentIndexPosition < stringLength) {
				currentReturn = currentReturn + currentChar;
				currentIndexPosition++;
					if (currentIndexPosition < toScan.length()){
					currentChar = toScan.charAt(currentIndexPosition);
					}
			}
		}
		
		return currentReturn;
	}
	
	public void setString(String input) {
		toScan = input;
		stringLength = toScan.length();
		currentIndexPosition = 0;
	}
	
	private void setInitialConditions(String input) {
		toScan = input;
		
		if (input.length() < 1) {
			toScan = " ";
		}
		
		
		stringLength = toScan.length();
		currentIndexPosition = 0;
	}
	
	private void clearWhiteSpace() {
		char currentChar = 'a';
		if ((currentIndexPosition < stringLength)) {
			currentChar = toScan.charAt(currentIndexPosition);
		}	
		while ((currentChar == ' ') && currentIndexPosition < stringLength) {
			currentIndexPosition++;
			if (!(currentIndexPosition >= stringLength)) {
				currentChar = toScan.charAt(currentIndexPosition);
			} else {
				break;
			}
		}
	}
	
	
}	
