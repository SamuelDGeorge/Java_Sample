package grail.scanner;

import java.util.Iterator;

public class DigitScanner implements Iterator<String>{

	private String toScan = "";
	private int stringLength = 0;
	private int currentIndexPosition = 0;
	
	public DigitScanner() {
		
	}
	
	public DigitScanner(String input) {
		setInitialConditions(input);
	}

	public boolean hasNext() {
		char currentChar = 'a';
		
		//probes for the next number. If it does not find one it returns false.
		int currentPosition = currentIndexPosition;
		if ((currentPosition < stringLength)) {
			currentChar = toScan.charAt(currentPosition);	
		while ((!Character.isDigit(currentChar))) {
			currentPosition++;
			if ((currentPosition < stringLength)) {
				currentChar = toScan.charAt(currentPosition);
			} else {
				currentPosition++;
				break;
			}
		}
		}
		
		if (currentPosition < stringLength) {
			return true;
		} 
			return false;
		
	}

	public String next() {

		String currentNumber = "";
		char currentChar = toScan.charAt(currentIndexPosition);
		if (Character.isDigit(currentChar)) {
			while (Character.isDigit(currentChar)) {
				currentNumber = currentNumber + currentChar;
				currentIndexPosition++;
				if (currentIndexPosition < toScan.length()) {
				currentChar = toScan.charAt(currentIndexPosition);
				} else {
					break;
				}
			}
		} else {
			clearToNumber();
			if (currentIndexPosition < toScan.length()) {
				currentChar = toScan.charAt(currentIndexPosition);
				}
			while (Character.isDigit(currentChar)) {
				currentNumber = currentNumber + currentChar;
				currentIndexPosition++;
				if (currentIndexPosition < toScan.length()) {
				currentChar = toScan.charAt(currentIndexPosition);
				} else {
					break;
				}
			}
			
		}		
		
		return currentNumber;
	}
	
	public void setString(String input) {
		toScan = input;
		stringLength = toScan.length();
		currentIndexPosition = 0;
	}
	
	private void setInitialConditions(String input) {
toScan = input;
		
		if (input.length() < 1) {
			toScan = " ";
		}
		stringLength = toScan.length();
		currentIndexPosition = 0;
	}
	
	private void clearToNumber() {
		char currentChar = 'a';
		if ((currentIndexPosition < stringLength)) {
			currentChar = toScan.charAt(currentIndexPosition);
		}	
		while ((!Character.isDigit(currentChar)) && currentIndexPosition < stringLength) {
			currentIndexPosition++;
			if ((currentIndexPosition < stringLength)) {
				currentChar = toScan.charAt(currentIndexPosition);
			} else {
				break;
			}
		}
	}
	
}	
