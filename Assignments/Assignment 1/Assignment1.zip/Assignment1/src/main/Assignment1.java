package main;

import java.util.Scanner;
import grail.scanner.DigitScanner;
import grail.scanner.TokenScanner;

public class Assignment1 {
	private boolean periodNotPresent = true;
	
	public Assignment1() {
		//does nothing
	}
	
	public static void main(String[] args) {
		boolean keepRunning = true;
		Scanner input = new Scanner(System.in);
		Assignment1 processor = new Assignment1();
		
		
		System.out.println("Welcome to number string!");
		while (keepRunning) {
			System.out.println("Please give a string of numbers:");
			String currentString = input.nextLine();
			String outputString = processor.processInputString(currentString);
			System.out.println(outputString);
			keepRunning = processor.getPeriodNotEntered();
			
		}
		
		input.close();
	}
	
	public String processInputString(String input) {
		String returnString = "";
		String rawNumberString = "";
		String errorStringStart = "Report, These inputs were found in error and were fixed: ";
		String errorStringFinish = "";
		
		TokenScanner scan = new TokenScanner(input);
		String firstToken = scan.next();
		
		//deals with the case of exiting
		if (firstToken.length() > 0 && firstToken.charAt(0) == '.') {
			returnString = "Thank you for using Number String!";
			periodNotPresent = false;
			return returnString;
		} else {
			scan.setString(input);
		}
		
		//runs the program assuming the user does not want to exit
		while (scan.hasNext()) {
			String currentToken = scan.next();
			try {
				int currentNumber = Integer.parseInt(currentToken); //can throw number format exception
				rawNumberString = rawNumberString + currentNumber + " "; 
			} catch (NumberFormatException e) {  
				//this collects the errors and reports them if a token is in error. "4jk5;" for example.
				DigitScanner fixer = new DigitScanner(currentToken);
				String fixedDigits = "";
				while (fixer.hasNext()) {
					String fixedNumber = fixer.next();
					rawNumberString = rawNumberString + fixedNumber + " ";
					fixedDigits = fixedDigits + fixedNumber + " ";
				} 
				
				if (fixedDigits.length() < 1 || fixedDigits.charAt(0) == ' '){
					fixedDigits = "No Numbers were found. Token Ignored!";
				}
				
				errorStringFinish = errorStringFinish + "\nThe following had a number format exception: " + currentToken + "\n"
						+ "It was corrected to: " + fixedDigits;
			}
		}
		
		
		if (errorStringFinish.length() < 1 || errorStringFinish.charAt(0) == ' '){
			errorStringFinish = "\nNo Errors Found!";
		}

		rawNumberString = formatNumberString(rawNumberString); //removes excess spaces
		String sum = sumString(rawNumberString);
		String product = productString(rawNumberString);
		
		returnString = "Numbers: " + rawNumberString + "Sum: " + sum + " Product: " + product + "\n" + 
						errorStringStart + errorStringFinish;
		
		
		return returnString;
	}
	
	
	private String sumString(String input) {
		String sum = "";
		int summer = 0;
		DigitScanner scanner = new DigitScanner(input);
		while(scanner.hasNext()) {
			String nextNumber = "";
			nextNumber = scanner.next();
			summer = summer + Integer.parseInt(nextNumber);
			
		}
		sum = "" + summer + "";
		return sum;
	}
	
	private String productString(String input) {
		String product = "";
		int multiple = 1;
		DigitScanner scanner = new DigitScanner(input);
		while(scanner.hasNext()) {
			String nextNumber = "";
			nextNumber = scanner.next();
			multiple = multiple * Integer.parseInt(nextNumber);
			
		}
		product = "" + multiple + "";
		return product;
	}
	
	private String formatNumberString(String input) {
		String ret = "";
		DigitScanner scan = new DigitScanner(input);
		while (scan.hasNext()) {
			String nextNumber = scan.next();
			ret = ret + nextNumber + " ";
		}
		return ret;
	}
	
	public boolean getPeriodNotEntered() {
		return periodNotPresent;
	}


}
