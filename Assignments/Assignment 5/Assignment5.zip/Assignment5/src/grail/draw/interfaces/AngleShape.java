package grail.draw.interfaces;

public interface AngleShape extends Shape{
		public void setAngle(double newAngle);
		public void setRadius(double newRadius);
		public void setHeight(int height);
		public void setWidth(int width);
		public RotatingShape getLeftLine();
		public RotatingShape getRightLine();
		public void move(int x, int y);
		public void rotate(int units);
		public double getRadius();
		public double getAngle();
}
