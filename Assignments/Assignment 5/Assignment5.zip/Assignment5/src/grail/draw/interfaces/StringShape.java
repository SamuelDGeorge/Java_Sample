package grail.draw.interfaces;

import java.awt.Color;

public interface StringShape {
	public int getX();
	public void setX(int newX);
	public int getY();
	public void setY(int newY);
	public String getText();
	public void setText(String text);
	public Color getColor();
	public void setColor(Color newColor);
	public void setString(String text);
	public String getString();
}
