package grail.draw.interfaces;

public interface ImageShape extends BasicShape {
	public String getImageFileName();  
    public void setImageFileName(String newName);
}
