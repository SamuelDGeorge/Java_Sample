package grail.draw.objects;

import java.awt.Color;

import grail.draw.interfaces.RotatingShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"RotatingLine"})
@StructurePattern(StructurePatternNames.LINE_PATTERN)
@PropertyNames({"X", "Y", "Height", "Width","Color"})
@EditablePropertyNames({"X", "Y","Angle", "Radius","Color"})
public class LineRotatingShape implements RotatingShape{
	private int x, y, width, height;
	private double radius, angle;
	private Color lineColor;

	public LineRotatingShape() {
	this(0,0,0,0);
	}
	
	public LineRotatingShape(int x, int y, double radius, double angle) {
		this.x = x;
		this.y = y;
		setRadius(radius);
		setAngle(angle);
		this.lineColor = Color.black;
	}

	@Override
	public int getX() {
		return x;
	}

	@Override
	public void setX(int x) {
		this.x = x;
		
	}

	@Override
	public int getY() {
		return y;
	}

	@Override
	public void setY(int y) {
		this.y = y;
		
	}

	@Override
	public int getHeight() {
		return height;
	}

	@Override
	public int getWidth() {
		return width;
	}

	@Override
	public void setRadius(double val) {
		this.radius = val;
		double tempHeight =  this.radius * Math.sin(this.angle);
		this.height = (int) tempHeight;
		double tempWidth = this.radius * Math.cos(this.angle);
		this.width = (int) tempWidth;
		
	}

	@Override
	public void setAngle(double val) {
		this.angle = val;
		double tempHeight =  this.radius * Math.sin(this.angle);
		this.height = (int) tempHeight;
		double tempWidth = this.radius * Math.cos(this.angle);
		this.width = (int) tempWidth;
		
	}

	@Tags({"rotate"})
	public void rotate(int units) {
		final double secondsInAMinute = 60;
		final double fullRotation = Math.PI * 2;
		final double clockUnit = fullRotation/secondsInAMinute;
		double distanceToRotate = units * clockUnit;
		double angleToSet = this.angle + distanceToRotate;
		setAngle(angleToSet);
	}

	@Override
	public Color getColor() {
		return lineColor;
		
	}

	@Override
	public void setColor(Color newColor) {
		this.lineColor = newColor;
		
	}

}
