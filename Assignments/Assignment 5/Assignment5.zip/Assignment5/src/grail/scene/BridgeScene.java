package grail.scene;

import grail.avatar.Avatar;

public interface BridgeScene {
	public Avatar getArthur();
	public Avatar getLancelot();
	public Avatar getRobin();
	public Avatar getGalahad();
	public Avatar getGuard();

}
