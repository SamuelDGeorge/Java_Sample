package grail.scene;

import grail.avatar.Avatar;
import grail.avatar.BasicAvatar;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"BridgeScene"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Arthur", "Lancelot", "Robin", "Galahad","Guard"})
@EditablePropertyNames({})
public class BasicBridgeScene implements BridgeScene {
	
	private Avatar arthur, lancelot, robin, galahad, guard;
	
	public BasicBridgeScene() {
		this(new BasicAvatar("arthur.jpg"), new BasicAvatar("lancelot.jpg"), new BasicAvatar("robin.jpg"), new BasicAvatar("galahad.jpg"), new BasicAvatar("guard.jpg"));
	}
	
	public BasicBridgeScene(Avatar arthur, Avatar lancelot, Avatar robin, Avatar galahad, Avatar guard) {
		this.arthur = arthur;
		this.lancelot = lancelot;
		this.galahad = galahad;
		this.robin = robin;
		this.guard = guard;
		
		
		//position in default locations
		final int firstLineY = 50;
		final int secondLineY = 300;
		final int lancelotAndGalahadX = 250;
		final int robinAndArthurX = 50;
		final int guardX = 450;
		arthur.setLocation(robinAndArthurX, firstLineY);
		arthur.setStoredText("Hello, I am Arthur!");
		

		lancelot.setLocation(lancelotAndGalahadX, firstLineY);
		lancelot.setStoredText("I am Lancelot!");
		

		robin.setLocation(robinAndArthurX, secondLineY);
		robin.setStoredText("I am Robin!");
		

		galahad.setLocation(lancelotAndGalahadX, secondLineY);
		galahad.setStoredText("I am Galahad!");
		

		guard.setLocation(guardX, secondLineY);
		guard.setStoredText("I am the Guard!");
	}

	public Avatar getArthur() {
		return arthur;
	}


	public Avatar getLancelot() {
		return lancelot;
	}

	
	public Avatar getRobin() {
		return robin;
	}

	
	public Avatar getGalahad() {
		return galahad;
	}

	
	public Avatar getGuard() {
		return guard;
	}
	
	

}
