package grail.command;
import util.annotations.Tags;

@Tags({"wait"})
public class WaitCommandToken extends CommandStoreToken {

	public WaitCommandToken(String input) {
		super(input);
		
	}

}
