package grail.command;

import util.annotations.Tags;

@Tags({"rotateRightArm"})
public class RotateRightArmCommandToken extends CommandStoreToken {

	public RotateRightArmCommandToken(String input) {
		super(input);
	}

}
