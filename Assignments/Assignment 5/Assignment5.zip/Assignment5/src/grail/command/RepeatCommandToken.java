package grail.command;

import util.annotations.Tags;

@Tags({"repeat"})
public class RepeatCommandToken extends CommandStoreToken {

	public RepeatCommandToken(String input) {
		super(input);
		// TODO Auto-generated constructor stub
	}

}
