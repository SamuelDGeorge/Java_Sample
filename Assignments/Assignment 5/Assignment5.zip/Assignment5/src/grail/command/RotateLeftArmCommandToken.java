package grail.command;

import util.annotations.Tags;

@Tags({"rotateLeftArm"})
public class RotateLeftArmCommandToken extends CommandStoreToken {

	public RotateLeftArmCommandToken(String input) {
		super(input);
	}

}
