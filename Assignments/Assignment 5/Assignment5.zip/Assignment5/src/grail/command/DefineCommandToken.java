package grail.command;
import util.annotations.Tags;

@Tags({"define"})
public class DefineCommandToken extends CommandStoreToken {

	public DefineCommandToken(String input) {
		super(input);
	}

}
