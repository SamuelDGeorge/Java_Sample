package grail.command;
import util.annotations.Tags;

@Tags({"thread"})
public class ThreadCommandToken extends CommandStoreToken {

	public ThreadCommandToken(String input) {
		super(input);
	}

}
