package grail.command;
import util.annotations.Tags;

@Tags({"call"})
public class CallCommandToken extends CommandStoreToken {

	public CallCommandToken(String input) {
		super(input);
		
	}

}
