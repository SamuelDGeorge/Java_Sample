package grail.avatar;

import java.awt.Color;

import grail.draw.interfaces.AngleShape;
import grail.draw.interfaces.ImageShape;
import grail.draw.interfaces.RotatingShape;
import grail.draw.interfaces.StringShape;
import grail.draw.objects.BasicAngleShape;
import grail.draw.objects.BasicImageShape;
import grail.draw.objects.BasicStringShape;
import grail.draw.objects.LineRotatingShape;
import util.annotations.EditablePropertyNames;
import util.annotations.PropertyNames;
import util.annotations.StructurePattern;
import util.annotations.StructurePatternNames;
import util.annotations.Tags;

@Tags({"Avatar"})
@StructurePattern(StructurePatternNames.BEAN_PATTERN)
@PropertyNames({"Head", "Arms", "Legs", "Body", "X", "Y", "StoredText", "Text", "BodyColor", "TextColor"})
@EditablePropertyNames({"X", "Y", "Text", "StoredText","BodyColor", "TextColor"})
public class BasicAvatar implements Avatar{
	private AngleShape arms, legs;
	private RotatingShape body;
	private ImageShape head;
	private StringShape text;
	private int xPos, yPos;
	private String storedText;
	private Color bodyColor, textColor;
	private int scaleFactor;
	
	
	public BasicAvatar(ImageShape head, int xPosStart, int yPosStart) {
		final int startingScaleFactor = 100;
		this.scaleFactor = startingScaleFactor;
		this.xPos = xPosStart;
		this.yPos = yPosStart;
		this.head = head;
		this.text = new BasicStringShape("Default", 0, 0);
		this.storedText = this.text.getString();
		this.body = new LineRotatingShape();
		this.arms = new BasicAngleShape(0, 0);
		this.legs = new BasicAngleShape(0, 0);		
		
		
		connectAvatar(xPosStart, yPosStart);
		final int defaultArmPosition = 8;
		this.arms.rotate(defaultArmPosition);
		this.legs.rotate(-defaultArmPosition);
		setBodyColor(Color.BLACK);
		setTextColor(Color.BLACK);
	}
	
	public BasicAvatar(String headImageString) {
		this(new BasicImageShape(headImageString));
		
	}
	
	public BasicAvatar(ImageShape head) {
		this (head, 0, 0);
	}

	
	public StringShape getText() {
		return text;
	}

	
	public void setText(StringShape setVal) {
		this.text = setVal;
		
	}

	
	public ImageShape getHead() {
		return head;
	}

	
	public AngleShape getArms() {
		return arms;
	}

	
	public AngleShape getLegs() {
		return legs;
	}

	
	public RotatingShape getBody() {
		return body;
	}

	@Tags({"move"})
	public void move(int x, int y) {
		this.xPos = this.xPos + x;
		this.yPos = this.yPos + y;
		connectAvatar(this.xPos, this.yPos);
		
	}

	
	public void setX(int xPos) {
		int xChange = xPos - this.xPos;
		move(xChange, 0);
		this.xPos = xPos;
		
		
	}

	
	public int getX() {
		return xPos;
	}

	
	public void setY(int yPos) {
		int yChange = yPos - this.yPos;
		move(0, yChange);
		this.yPos = yPos;
		
	}

	
	public int getY() {
		return yPos;
	}

	@Tags({"scale"})
	public void scale(double scaleValue) {
		this.scaleFactor = (int) (this.scaleFactor * scaleValue);
		connectAvatar(this.xPos,this.yPos);
		
		
	}

	
	public void setStoredText(String text) {
		this.storedText = text;
		this.text.setText(text);	
	}

	
	public String getStoredText() {
		return this.storedText;
	}
	
	public void setLocation(int x, int y) {
		connectAvatar(x,y);
		
	}
	
	private void connectAvatar(int xPos, int yPos) {
		int singleScaleFactor = this.scaleFactor;
		this.xPos = xPos;
		this.yPos = yPos;
		int headWidth = head.getWidth();
		int headHeight = head.getHeight();
		int xBodyPosition = headWidth/2 + xPos;
		int yBodyPosition = headHeight + yPos;
		
		this.head.setX(xPos);
		this.head.setY(yPos);
		
		this.body.setX(xBodyPosition);
		this.body.setY(yBodyPosition);
		this.body.setRadius(singleScaleFactor);
		this.body.setAngle(Math.PI/2);
		
		final double armScaleFactor = .40;
		final double armLengthFactor = .5;
		int armLocation = (int) (headHeight + yPos + singleScaleFactor * (armScaleFactor));
		this.arms.setX(xBodyPosition);
		this.arms.setY(armLocation);
		this.arms.getRightLine().setRadius(singleScaleFactor * armLengthFactor);
		this.arms.getLeftLine().setRadius(singleScaleFactor * armLengthFactor);
		
		final double legScaleFactor = .5;
		int bodyLocation = headHeight + yPos + singleScaleFactor;
		this.legs.setX(xBodyPosition);
		this.legs.setY(bodyLocation);
		this.legs.getRightLine().setRadius(singleScaleFactor * legScaleFactor);
		this.legs.getLeftLine().setRadius(singleScaleFactor * legScaleFactor);

		final int speachDistanceFromMouth = 10;
		this.text.setX(headWidth + xPos + speachDistanceFromMouth);
		this.text.setY(headHeight + yPos);

	}
	
	
	public void setBodyColor(Color newBodyColor) {
		this.bodyColor = newBodyColor;
		this.body.setColor(newBodyColor);
		this.arms.getRightLine().setColor(newBodyColor);
		this.arms.getLeftLine().setColor(newBodyColor);
		this.legs.getRightLine().setColor(newBodyColor);
		this.legs.getLeftLine().setColor(newBodyColor);
		
	}

	
	public void setTextColor(Color newTextColor) {
		this.textColor = newTextColor;
		this.text.setColor(newTextColor);
		
	}

	
	public Color getBodyColor() {
		return bodyColor;
	}

	
	public Color getTextColor() {
		return textColor;
	}


}
