package main;

import java.awt.Color;

import bus.uigen.OEFrame;
import bus.uigen.ObjectEditor;
import grail.avatar.Avatar;
import grail.avatar.BasicAvatar;
import grail.scene.BasicBridgeScene;
import grail.scene.BridgeScene;
import util.misc.ThreadSupport;

public class Assignment5 {
	
	public static void main(String[] args) {
        demonstrateBridgeScene();
	}
	
	private static void demonstrateBridgeScene() {
		//build the avatar
		Avatar arthur = new BasicAvatar("arthur.jpg");
		arthur.setBodyColor(Color.YELLOW);
		arthur.setTextColor(Color.YELLOW);
		
		Avatar lancelot = new BasicAvatar("lancelot.jpg");
		lancelot.setBodyColor(Color.RED);
		lancelot.setTextColor(Color.RED);
		
		Avatar robin =  new BasicAvatar("robin.jpg");
		robin.setBodyColor(Color.CYAN);
		robin.setTextColor(Color.CYAN);
		
		Avatar galahad = new BasicAvatar("galahad.jpg");
		galahad.setBodyColor(Color.PINK);
		galahad.setTextColor(Color.PINK);
		
		Avatar guard = new BasicAvatar("guard.jpg");
		guard.setBodyColor(Color.DARK_GRAY);
		guard.setTextColor(Color.DARK_GRAY);

		//Create the scene
		BridgeScene testBridge = new BasicBridgeScene(arthur, lancelot, robin, galahad, guard);
		OEFrame editor = ObjectEditor.edit(testBridge);
		
		final int windowDimensions = 1000;
		final int pauseTimeInMS = 3000;
		final int waveTimeInMS = 500;
		final int armWaveUnits = 8;
		final int numberOfWaves = 10;
		final int unitsToMoveRightBegin = 50;
		final int unitsToMoveRight = 400;
		final int unitsToMoveScaled = 100;
		final int unitsToMoveDown = 0;
		final int scaleUnits = 2;
		
		//act out the scene 
		editor.setSize(windowDimensions, windowDimensions);
		editor.refresh();
		
		arthur.setStoredText("Move Everyone!");
		editor.refresh();
		ThreadSupport.sleep(pauseTimeInMS);
		
		//move demonstration
		lancelot.move(unitsToMoveRight + unitsToMoveRightBegin, unitsToMoveDown);
		arthur.move(unitsToMoveRightBegin, unitsToMoveDown);
		robin.move(unitsToMoveRightBegin, unitsToMoveDown);
		galahad.move(unitsToMoveRightBegin, unitsToMoveDown);
		guard.move(unitsToMoveRightBegin, unitsToMoveDown);
		
		editor.refresh();
		
		//arm waving demonstration
		arthur.setStoredText("Now Wave, Lancelot!!");
		lancelot.setStoredText("I will wave, my Lord");
		ThreadSupport.sleep(pauseTimeInMS);
		editor.refresh();
		int count = 0;
		while (count < numberOfWaves) {
			if (count % 2 == 0) {
				lancelot.getArms().getRightLine().rotate(armWaveUnits);
			} else {
				lancelot.getArms().getRightLine().rotate(-armWaveUnits);
			}
			editor.refresh();
			ThreadSupport.sleep(waveTimeInMS);
			count++;
		}
		arthur.setStoredText("Now prepare for battle! Get Big!!");
		lancelot.setStoredText("Yes my Lord!");
		editor.refresh();
		ThreadSupport.sleep(pauseTimeInMS);
		
		//scale demonstration
		lancelot.setStoredText("Ready for Battle!!");
		lancelot.scale(scaleUnits);
		editor.refresh();
		ThreadSupport.sleep(pauseTimeInMS);
		
		//moving while scaled demonstration
		lancelot.move(unitsToMoveScaled, 0);
		lancelot.setStoredText("To Battle!!");
		editor.refresh();
		ThreadSupport.sleep(pauseTimeInMS);
		editor.dispose();
	}

	
}
